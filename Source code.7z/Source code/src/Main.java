/*
 * Main Class of the Program
 */
import controller.Controller;
import view.Window;
import model.Mandelbrot;

public class Main {
    public static void main(String[] args) {
    	//Initial MVC
        Mandelbrot model = new Mandelbrot();
        Window view = new Window(model);
        Controller controller = new Controller(model, view);
        model.create_DefaultValues();
    }
}
