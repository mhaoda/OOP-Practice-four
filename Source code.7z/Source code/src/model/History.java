/*
 * the History model for redo or undo function
 */
package model;

import java.awt.Font;
import java.util.Stack;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class History {
	private Stack<double[]> undo;
	private Stack<double[]> redo;
	/*
	 * Constructor
	 */
	public History() {
		undo = new Stack<>();
		redo = new Stack<>();
	}
	//add new history
	public void newHistory(double[] array) {
		if (!redo.empty()) {
			redo.clear();
		}
		undo.push(array);
	}
	//undo the operation
	public double[] undo() {
		redo.push(undo.pop());
		if (!undo.empty()) {
			return undo.peek();
		} else {
			//alert for no withdrawal
			JLabel label = new JLabel("No more item can withdraw!");
            label.setFont(new Font("Arial", Font.BOLD, 20));
            JOptionPane.showMessageDialog(null, label, "Alert", JOptionPane.INFORMATION_MESSAGE);
            // returns the current parameters
            undo.push(redo.pop());
			return undo.peek();
		}
	}
	//redo the operation
	public double[] redo() {
		if (!redo.empty()) {
			undo.push(redo.pop());
			return undo.peek();
		}else {
			//alert for nothing to redo
			JLabel label = new JLabel("No more withdrawal!");
            label.setFont(new Font("Arial", Font.BOLD, 20));
            JOptionPane.showMessageDialog(null, label, "Alert", JOptionPane.INFORMATION_MESSAGE);
            return undo.peek();
		}
		
	}
}
