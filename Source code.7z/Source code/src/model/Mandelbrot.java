/*
 * Mandelbrot model
 */
package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Observable;

public class Mandelbrot extends Observable{


    private MandelbrotCalculator calculator;

    private int xResolution, yResolution;
    private double minReal, maxReal, minImaginary, maxImaginary, radiusSquared;
    private int maxIterations;
    private int[][] mandelbrotArray;
    private History history;
    
    public int getxResolution() {
		return xResolution;
	}
	public void setxResolution(int xResolution) {
		this.xResolution = xResolution;
	}
	public int getyResolution() {
		return yResolution;
	}
	public void setyResolution(int yResolution) {
		this.yResolution = yResolution;
	}
	public double getMinReal() {
		return minReal;
	}
	public void setMinReal(double minReal) {
		this.minReal = minReal;
	}
	public double getMaxReal() {
		return maxReal;
	}
	public void setMaxReal(double maxReal) {
		this.maxReal = maxReal;
	}
	public double getMinImaginary() {
		return minImaginary;
	}
	public void setMinImaginary(double minImaginary) {
		this.minImaginary = minImaginary;
	}
	public double getMaxImaginary() {
		return maxImaginary;
	}
	public void setMaxImaginary(double maxImaginary) {
		this.maxImaginary = maxImaginary;
	}
	public int getMaxIterations() {
		return maxIterations;
	}
	public void setMaxIterations(int maxIterations) {
		this.maxIterations = maxIterations;
	}
	public double getRadiusSquared() {
		return radiusSquared;
	}
	public void setRadiusSquared(double radiusSquared) {
		this.radiusSquared = radiusSquared;
	}
    public int[][] getMandelbrotArray() {
        return mandelbrotArray;
    }
	
	public Mandelbrot() {
		calculator = new MandelbrotCalculator();
		history = new History();
	}
	//create the Mandelbrot set with parameters
	public void create(double minReal, double maxReal, double minImaginary, double maxImaginary, int maxIterations, double radiusSquared) {
		this.minReal = minReal;
        this.maxReal = maxReal;
        this.minImaginary = minImaginary;
        this.maxImaginary = maxImaginary;
        this.maxIterations = maxIterations;
        this.radiusSquared = radiusSquared;
	}
	//calculate Mandelbrot set by Mandelbrot calculator
    public void calculate(int xResolution, int yResolution, double minReal, double maxReal, double minImaginary, double maxImaginary, int maxIterations, double radiusSquared) {
        create(minReal, maxReal, minImaginary, maxImaginary, maxIterations, radiusSquared);
        addNewHistory(minReal, maxReal, minImaginary, maxImaginary, maxIterations, radiusSquared);
        mandelbrotArray = calculator.calcMandelbrotSet(xResolution, yResolution, minReal, maxReal, minImaginary, maxImaginary, maxIterations, radiusSquared);
        setChanged();//sign for the change
        notifyObservers();//notice object observer that has changed, active update method
    }
    //create Mandelbrot set with the default value
    public void create_DefaultValues() {
        calculate(xResolution, yResolution, MandelbrotCalculator.INITIAL_MIN_REAL, MandelbrotCalculator.INITIAL_MAX_REAL, MandelbrotCalculator.INITIAL_MIN_IMAGINARY, MandelbrotCalculator.INITIAL_MAX_IMAGINARY, MandelbrotCalculator.INITIAL_MAX_ITERATIONS, MandelbrotCalculator.DEFAULT_RADIUS_SQUARED);
    }
    //change the max iterations
    public void create_MaxIterations(int maxIterations) {
        calculate(xResolution, yResolution, minReal, maxReal, minImaginary, maxImaginary, maxIterations, radiusSquared);
    }
    //create Mandelbrot set with the parameter of last operation
    public void undo() {
        double[] array = history.undo();
        calculate_notUpdate(xResolution, yResolution, array[0], array[1], array[2], array[3], (int) array[4], array[5]);
    }
    //create Mandelbrot set with the parameter of the withdraw Mandelbrot 
    public void redo() {
        double[] array = history.redo();
        calculate_notUpdate(xResolution, yResolution, array[0], array[1], array[2], array[3], (int) array[4], array[5]);
    }
    //create Mandelbrot set without adding it into history
    public void calculate_notUpdate(int xResolution, int yResolution, double minReal, double maxReal, double minImaginary, double maxImaginary, int maxIterations, double radiusSquared) {
        create(minReal, maxReal, minImaginary, maxImaginary, maxIterations, radiusSquared);
        mandelbrotArray = calculator.calcMandelbrotSet(xResolution, yResolution, minReal, maxReal, minImaginary, maxImaginary, maxIterations, radiusSquared);
        setChanged();
        notifyObservers();
    }
    //add the Mandelbrot set into undo stack
    public void addNewHistory(double minReal, double maxReal, double minImaginary, double maxImaginary, int maxIterations, double radiusSquared) {
        history.newHistory(new double[]{minReal, maxReal, minImaginary, maxImaginary, maxIterations, radiusSquared});
    }
    //exporting Mandelbrot set parameters
    public void Export(File file){
        try {
			FileOutputStream fos = new FileOutputStream(file); 
			PrintStream ps = new PrintStream(fos);
			double[] parameters = {xResolution, yResolution, minReal, maxReal, minImaginary, maxImaginary, maxIterations, radiusSquared};
			ps.print("xResolution: " + parameters[0] + " yResolution: "+ parameters[1] +" MinReal: "+ parameters[2] +" MaxReal: "+ parameters[3] +" MinImaginary: " + parameters[4] + " MaxImaginary: " + parameters[5] + " MaxIterations: " + parameters[6] + " RadiusSquared: " + parameters[7]);
			ps.close();
			fos.close();
        } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    //importing Mandelbrot set parameters
    public void Import(File file) {
        try {
			FileInputStream fis = new FileInputStream(file); 
			BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
			String array = bufferedReader.readLine();
			array = array.replaceAll("[a-zA-Z]", "");
			array = array.replaceAll(":", "");
			array = array.trim();
			String[] parameters = array.split("  ");
			double xresolution = Double.valueOf(parameters[0]);
			double yresolution = Double.valueOf(parameters[1]);
			double maxiterations = Double.valueOf(parameters[6]);;
			calculate((int)xresolution, (int)yresolution, Double.valueOf(parameters[2]), Double.valueOf(parameters[3]), Double.valueOf(parameters[4]), Double.valueOf(parameters[5]), (int)maxiterations, Double.valueOf(parameters[7]));
			bufferedReader.close();
			fis.close();
        } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
