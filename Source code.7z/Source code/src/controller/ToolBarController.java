/*
 * ToolBar Controller
 */
package controller;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import model.Mandelbrot;
import view.Toolbar;

public class ToolBarController {
	
	/*
	 * Constructor of Tool bar controller
	 * @param Mandelbrot model
	 * @param toolbar model
	 */
    public ToolBarController(Mandelbrot mandelbrot, Toolbar toolbar) {
    	
    	//The function of the reset button.
    	toolbar.getResetButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mandelbrot.create_DefaultValues();
            }
        });
    	
    	//The function of the undo button.
        toolbar.getUndoButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mandelbrot.undo();
            }
        });
        
        //The function of the redo button.
        toolbar.getRedoButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mandelbrot.redo();
            }
        });
    	
        //The function of the re-calculate with the new Max iteration.
        toolbar.getCalcButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                	//get the inputed value
					int i = Integer.parseInt(toolbar.getIteration().getText());
					//judgement of the inputed value from user
					if (i > 0){
					    mandelbrot.create_MaxIterations(Integer.parseInt(toolbar.getIteration().getText()));
					} else{
						//input negative number
						 JLabel label = new JLabel("Please input the posiitive number");
			             label.setFont(new Font("Arial", Font.BOLD, 20));
			             JOptionPane.showMessageDialog(null, label, "Alert", JOptionPane.ERROR_MESSAGE);
					}
				} catch (NumberFormatException e1) {
					//input nothing
					 JLabel label = new JLabel("Please input the Max iteration number");
		             label.setFont(new Font("Arial", Font.BOLD, 20));
		             JOptionPane.showMessageDialog(null, label, "Alert", JOptionPane.ERROR_MESSAGE);
				}
            }
        });
    
	}
}
