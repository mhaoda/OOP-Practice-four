/*
 * Main Controller that used to create other controllers
 */
package controller;

import model.Mandelbrot;
import view.Window;

public class Controller {

    private Mandelbrot mandelbrot;
    private Window window;
    private ToolBarController toobarController;
    private PanelController zoomController;
    private MenuController menuController;
    /*
     * Constructor
     * @param Mandelbrot model
     * @param Window model 
     */
    public Controller(Mandelbrot mandelbrot, Window window) {
        this.mandelbrot = mandelbrot;
        this.window = window;
        mandelbrot.setxResolution(window.getWIDTH());
        mandelbrot.setyResolution(window.getHEIGHT());
        toobarController = new ToolBarController(mandelbrot, window.getMandelbrotToolbar());
        zoomController = new PanelController(mandelbrot, window.getMyPanel());
        menuController = new MenuController(mandelbrot, window);
    }
}
