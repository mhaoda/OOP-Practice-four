/*
 * Menu Controller
 */
package controller;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import model.Mandelbrot;
import view.Menubar;
import view.Window;

public class MenuController {
    public MenuController(Mandelbrot mandellbrot, Window window) {
        Menubar menubar = window.getMenubar();
        
        //The function of showing the instruction.
        menubar.getAbout().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JLabel label = new JLabel(
						  "<html>"
							+ "<br>The Mandelbrot set displayed in black and white in the window, and the color can be changed by selecting the items in the color menu."
							+ "<br>The Mandelbrot set can be zoomed in by mouse whell."
							+ "<br>User can drag the Mandelbrot set left, right, up and down by mouse click."
							+ "<br>Permit the user to alter the	value used for maxIterations so	as to enhance the precision	of the Mandelbrot image."
							+ "<br>Undo, Redo button�permit the user to undo/redo the last zoom or pan operation."
							+ "<br>The Export/Import in the File menu allow user to save the parameters of the set or load a Mandelbro set."
						+ "</html>");
                label.setFont(new Font("Arial", Font.BOLD, 20));
                JOptionPane.showMessageDialog(null, label, "About", JOptionPane.INFORMATION_MESSAGE);
			}
		});
        
        //The function of exporting Mandelbrot set.
        menubar.getExport().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	 JFileChooser fileChooser = new JFileChooser();
                 int returnVal = fileChooser.showSaveDialog(fileChooser);
                 if (returnVal == JFileChooser.APPROVE_OPTION) {
                     File file = fileChooser.getSelectedFile();
                         mandellbrot.Export(file);
                 }
            }
        });
        
        //The function of the importing Mandelbrot set. 
        menubar.getImport().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	 JFileChooser fileChooser = new JFileChooser();
                 int returnVal = fileChooser.showOpenDialog(fileChooser);
                 if (returnVal == JFileChooser.APPROVE_OPTION) {
                     File file = fileChooser.getSelectedFile();
                         mandellbrot.Import(file);
                 }
            	
            }
        });
        
        //The function for changing the color.
        
        //Black
        menubar.getBlack().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                window.getMyPanel().setColor("BLACK");
                window.draw();

            }
        });
        
        //Blue
        menubar.getBlue().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	window.getMyPanel().setColor("BLUE");
            	window.draw();
            }
        });
        
        //Red
        menubar.getRed().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	window.getMyPanel().setColor("RED");
            	window.draw();
            }
        });
        
        //Green
        menubar.getGreen().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	window.getMyPanel().setColor("GREEN");
            	window.draw();
            }
        });
    }
}
