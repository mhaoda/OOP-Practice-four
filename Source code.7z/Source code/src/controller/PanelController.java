/*
 * Panel Controller
 */
package controller;

import model.Mandelbrot;
import view.Panel;

public class PanelController  {
	
	private Panel panel;
    private Mandelbrot mandelbrot;
    private double half = 0.5;
    
    /*
     * Constructor 
     * @param Mandelbrot model
     * @param Panel model
     */
    public PanelController(Mandelbrot mandelbrot, Panel panel) {
        this.mandelbrot = mandelbrot;
        this.panel = panel;
    }
    
    /*
     * Recreate the Mandelbrot set for panning.
     * @param Mandelbrot model
     * @param x coordination of moved mouse
     * @param y coordination of moved mouse
     */
	public void panning(Mandelbrot mandelbrot, int x, int y) {
        double realRange = mandelbrot.getMaxReal() - mandelbrot.getMinReal();
        double imaginaryRange = mandelbrot.getMaxImaginary() - mandelbrot.getMinImaginary();
        double real = x * realRange / mandelbrot.getxResolution();
        double imaginary = y * imaginaryRange / mandelbrot.getyResolution();
        mandelbrot.setMinImaginary(mandelbrot.getMinImaginary() - imaginary);
        mandelbrot.setMaxImaginary(mandelbrot.getMaxImaginary() - imaginary);
        mandelbrot.setMaxReal(mandelbrot.getMaxReal() - real);
        mandelbrot.setMinReal(mandelbrot.getMinReal() - real);
    }
	
	/*
	 * Recreate the Mandelbrot set for zooming.
	 * @param Mandelbrot model
	 * @param the times of zooming in or zooming out 
	 */
	public void zoom(Mandelbrot mandelbrot, double times) {
		 double width = mandelbrot.getMaxReal() - mandelbrot.getMinReal();
	     double height = mandelbrot.getMaxImaginary() - mandelbrot.getMinImaginary();
	     double centreReal = (half * (mandelbrot.getMaxReal() - mandelbrot.getMinReal())) + mandelbrot.getMinReal();
	     double centreImaginary = (half * (mandelbrot.getMaxImaginary() - mandelbrot.getMinImaginary())) + mandelbrot.getMinImaginary();
	     mandelbrot.setxResolution(panel.getHeight());
	     mandelbrot.setyResolution(panel.getWidth());
	     mandelbrot.setMinReal(centreReal - (width * half * times));
	     mandelbrot.setMaxReal(centreReal + (width * half * times));
	     mandelbrot.setMinImaginary(centreImaginary - (height * half * times));
	     mandelbrot.setMaxImaginary(centreImaginary + (height * half * times));
	    }
}
