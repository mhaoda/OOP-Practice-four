/*
 * Menubar view
 */
package view;

import javax.swing.*;

public class Menubar extends JMenuBar {
	private static final long serialVersionUID = 1L;
	private JMenu file;
	private JMenuItem Export;
	private JMenuItem Import;
	private JButton About;
	private JMenu color;
	private JMenuItem black;
	private JMenuItem blue;
	private JMenuItem green;
	private JMenuItem red;
	

	public JMenuItem getExport() {
		return Export;
	}

	public JMenuItem getImport() {
		return Import;
	}
	
	public JButton getAbout() {
		return About;
	}

	public JMenuItem getBlack() {
		return black;
	}
	
	public JMenuItem getRed() {
		return red;
	}

	public JMenuItem getBlue() {
		return blue;
	}
	
	public JMenuItem getGreen() {
		return green;
	}
	/*
	 * Constructor
	 * add components into menu bar
	 */
	public Menubar() {
		file = new JMenu("File");
		Export = new JMenuItem("Export");
		Import = new JMenuItem("Import");
		About = new JButton("About");
		file.add(Export);
		file.add(Import);
		color = new JMenu("Color");
		black = new JMenuItem("Black");
		blue = new JMenuItem("Blue");
		red = new JMenuItem("Red");
		green = new JMenuItem("Green");
		color.add(black);
		color.add(blue);
		color.add(red);
		color.add(green);
		this.add(About);
		this.add(file);
		this.add(color);
		
	}
}
