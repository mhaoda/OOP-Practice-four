/*
 * window
 */
package view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.HeadlessException;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JFrame;

import model.Mandelbrot;

public class Window extends JFrame implements Observer, MouseWheelListener {
	private static final long serialVersionUID = 1L;
	private static final int WIDTH = 500;
	private static final int HEIGHT = 500;

	private Container container;
	private Mandelbrot mandelbrot;
	private Panel panel;
	private Toolbar toolbar;
	private Menubar menubar;
	
	public Panel getMyPanel() {
		return panel;
	}

	public Toolbar getMandelbrotToolbar() {
		return toolbar;
	}

	public Menubar getMenubar() {
		return menubar;
	}

	public static int getWIDTH() {
		return WIDTH;
	}

	public static int getHEIGHT() {
		return HEIGHT;
	}
	/*
	 * Constructor 
	 * @param Mandelbrot model
	 */
	public Window(Mandelbrot mandelbrot) throws HeadlessException {
		mandelbrot.addObserver(this);
		this.mandelbrot = mandelbrot;
		panel = new Panel(WIDTH, HEIGHT, mandelbrot);
		toolbar = new Toolbar(mandelbrot);
		menubar = new Menubar();
		container = getContentPane();
		container.add(panel, BorderLayout.CENTER);
		container.add(toolbar, BorderLayout.SOUTH);
		panel.addMouseWheelListener(this);
		setJMenuBar(menubar);
		setupFrame();
	}
	//setup window
	public void setupFrame() {
		this.setSize(WIDTH, HEIGHT + 100);
		setTitle("Mandelbrot Set");
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		// TODO Auto-generated method stub
		draw();
	}

	public void draw() {
		panel.drawMandelbrotSet();
		repaint();
	}
	//update the times of zooming
	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		// TODO Auto-generated method stub
		toolbar.getTimes().setText(panel.getTimes() + " times");
	}
}
