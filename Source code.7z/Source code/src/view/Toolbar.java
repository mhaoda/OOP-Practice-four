/*
 * Toolbar view
 */
package view;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JToolBar;

import model.Mandelbrot;

public class Toolbar extends JToolBar implements FocusListener{
	private static final long serialVersionUID = 1L;
	private JButton resetButton;
    private JButton undoButton;
    private JButton redoButton;
    private JButton calculateButton;
    private JTextField maxIteration;
    private JTextField times;
    private Mandelbrot mandelbrot;

    public JButton getUndoButton() {
        return undoButton;
    }

    public JButton getRedoButton() {
        return redoButton;
    }

    public JButton getResetButton() {
        return resetButton;
    }

    public JTextField getIteration() {
        return maxIteration;
    }

    public JTextField getTimes() {
		return times;
	}

	public JButton getCalcButton() {
        return calculateButton;
    }
    /*
     * Constructor
     * @param Mandelbrot model
     */
    public Toolbar(Mandelbrot mandelbrot) {
        resetButton = new JButton("Reset");
        undoButton = new JButton("Undo");
        redoButton = new JButton("Redo");
        calculateButton = new JButton("Recalculate");
        maxIteration = new JTextField("Input the max iteration number");
        times = new JTextField("1.0 times");
        times.setEditable(false);
        this.add(resetButton);
        this.add(undoButton);
        this.add(redoButton);
        this.add(calculateButton);
        this.add(maxIteration);
        this.add(times);
        this.mandelbrot = mandelbrot;
        maxIteration.addFocusListener(this);
    }
    //clean the notice when user clicks the text field
	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		 String temp = maxIteration.getText();
	        if(temp.equals("Input the max iteration number")){
	            maxIteration.setText("");
	     }
	}
	//put the value of the times into text field
	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		String temp = maxIteration.getText();
        if(temp.equals("")){
            maxIteration.setText("Input the max iteration number");
        }  
	}
}
