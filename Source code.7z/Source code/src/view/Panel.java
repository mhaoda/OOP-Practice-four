/*
 * Panel view
 */
package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import controller.PanelController;
import model.Mandelbrot;

public class Panel extends JPanel implements MouseMotionListener, MouseWheelListener {
	private static final long serialVersionUID = 1L;
	private BufferedImage canvas;
	private Graphics2D graphics2D;
	private Mandelbrot mandelbrot;
	private Color c = null;
	private int startX, startY, endX, endY;
	private double zoomTimes = 2;
	private double times = 1;
	private PanelController panelController = new PanelController(mandelbrot, this);

	public String getTimes() {
		return String.valueOf(times);
	}

	/*
	 * Constructor
	 * 
	 * @param panel width
	 * 
	 * @param panel height
	 * 
	 * @param Mandelbrot model
	 */
	public Panel(int width, int height, Mandelbrot mandelbrot) {
		canvas = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		graphics2D = canvas.createGraphics();
		this.addMouseMotionListener(this);
		this.addMouseWheelListener(this);
		this.mandelbrot = mandelbrot;
	}

	// select color for painting
	public void setColor(String color) {
		if (color.equals("RED")) {
			c = Color.RED;
		} else if (color.equals("GREEN")) {
			c = Color.GREEN;
		} else if (color.equals("BLUE")) {
			c = Color.BLUE;
		} else if (color.equals("BLACK")) {
			c = Color.BLACK;
		} else {
			c = null;
		}
	}

	// draw Mandelbrot set
	public void drawMandelbrotSet() {
		if (c == null) {
			graphics2D.setColor(Color.WHITE);
			graphics2D.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
			int[][] data = mandelbrot.getMandelbrotArray();
			Color c = null;
			for (int i = 0; i < data.length; i++) {
				for (int j = 0; j < data[i].length; j++) {
					int value = data[i][j];
					if (value == mandelbrot.getMaxIterations()) {
						c = Color.BLACK;
					} else {
						// c = new Color(value, value, value);
						double rate = (double) value / mandelbrot.getMaxIterations();
						c = new Color((int) (rate * 255), (int) (rate * 255), (int) (rate * 255));
					}
					graphics2D.setColor(c);
					graphics2D.drawLine(j, i, j, i);
				}
			}
		} else {
			graphics2D.setColor(Color.WHITE);
			graphics2D.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
			int[][] data = mandelbrot.getMandelbrotArray();
			Color color = null;
			for (int i = 0; i < data.length; i++) {
				for (int j = 0; j < data[i].length; j++) {
					int value = data[i][j];
					if (value == mandelbrot.getMaxIterations()) {
						color = Color.BLACK;
					} else if (c == Color.BLUE) {
						double rate = (double) value / mandelbrot.getMaxIterations();
						color = new Color((int) (rate * 0), (int) (rate * 0), (int) (rate * 255));
					} else if (c == Color.GREEN) {
						double rate = (double) value / mandelbrot.getMaxIterations();
						color = new Color((int) (rate * 0), (int) (rate * 255), (int) (rate * 0));
					} else if (c == Color.RED) {
						double rate = (double) value / mandelbrot.getMaxIterations();
						color = new Color((int) (rate * 255), (int) (rate * 0), (int) (rate * 0));
					} else if (c == Color.BLACK) {
						double rate = (double) value / mandelbrot.getMaxIterations();
						color = new Color((int) (rate * 255), (int) (rate * 255), (int) (rate * 255));
					}
					graphics2D.setColor(color);
					graphics2D.drawLine(j, i, j, i);
				}
			}
		}
	}
	
	/*
	 * catching mouse action
	 * getting the value of the mouse coordination and the value of mouse wheel
	 * using the value change the parameters then recreate Mandelbrot set with new parameters
	 * the way to change the parameter refers to the information online
	 */
	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		startX = endX;
		startY = endY;
		endX = e.getX();
		endY = e.getY();
		panelController.panning(mandelbrot, -1 * (startX - endX), -1 * (startY - endY));
		mandelbrot.create_MaxIterations(mandelbrot.getMaxIterations());
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		startX = endX;
		startY = endY;
		endX = e.getX();
		endY = e.getY();
	}

	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		// TODO Auto-generated method stub
		int rotation = e.getWheelRotation();
		if (rotation != 0) {
			panelController.zoom(mandelbrot, Math.pow(zoomTimes, rotation));
			times = times * Math.pow(zoomTimes, -rotation);
			mandelbrot.create_MaxIterations(mandelbrot.getMaxIterations());
		}
	}

	public void paintComponent(Graphics graphics2D) {
		super.paintComponent(graphics2D);
		graphics2D.drawImage(canvas, 0, 0, null);
	}
}
